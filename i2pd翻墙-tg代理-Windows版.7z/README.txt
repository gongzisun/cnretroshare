To use configs and certificates, move all files and certificates folder from contrib directory here.
